package somepkg;

public class OtherClass {

}
